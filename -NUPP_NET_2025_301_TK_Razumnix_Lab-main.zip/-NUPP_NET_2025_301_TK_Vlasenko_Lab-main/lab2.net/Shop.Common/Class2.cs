﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Shop.Common
{
    internal class Class2
    {
    }
}
